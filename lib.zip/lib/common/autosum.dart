class AutoSum {
// 

}